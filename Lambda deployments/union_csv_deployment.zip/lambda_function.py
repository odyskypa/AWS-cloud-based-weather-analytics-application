import csv
import os
import boto3
from datetime import datetime

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Get the name of the S3 bucket
    source_bucket = 'weather-csv-data'
    target_bucket = 'final-database'
    
    # List objects in the source bucket
    response = s3.list_objects_v2(Bucket=source_bucket)
    if 'Contents' not in response:
        return {
            'statusCode': 404,
            'body': 'No files found in the source bucket'
        }
    
    # Create a list to store the data from all CSV files
    csv_data = []
    
    # Process each CSV file in the source bucket
    for file_obj in response['Contents']:
        # Download the CSV file from the source S3 bucket
        temp_file_path = '/tmp/' + file_obj['Key']
        s3.download_file(source_bucket, file_obj['Key'], temp_file_path)

        # Read the CSV file
        with open(temp_file_path, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                csv_data.append(row)
    
    # Check if any CSV data was collected
    if len(csv_data) == 0:
        return {
            'statusCode': 404,
            'body': 'No CSV data found in the source bucket'
        }

    # Extract the columns from the first row
    columns = csv_data[0].keys()
    
    # Generate the CSV content
    csv_content = ''
    if len(csv_data) > 0:
        csv_content = ','.join(columns) + '\n'
        for row in csv_data:
            csv_content += ','.join(str(row.get(col, '')).encode('utf-8').decode('utf-8') for col in columns) + '\n'

    # Generate a timestamp for the file name
    timestamp = datetime.now().strftime("%y%m%d%H%M")
    
    # Upload the merged CSV file to the target S3 bucket with timestamp in the file name
    target_file_name = f'merged_data_{timestamp}.csv'
    s3.put_object(Body=csv_content.encode('utf-8'), Bucket=target_bucket, Key=target_file_name)
    
    return {
        'statusCode': 200,
        'body': f'Merged CSV file created successfully and uploaded to {target_bucket}/{target_file_name}'
    }
